// sidepanel.js
const scanButton = document.getElementById('scan-button');
const statusMessage = document.getElementById('status-message');
const resultsContainer = document.getElementById('results-container');
const resultTemplate = document.getElementById('result-item-template');

const showStatus = (message, isLoading = false) => {
    let loader = isLoading ? '<div class="loading-spinner"></div>' : '';
    statusMessage.innerHTML = `${loader}<p>${message}</p>`;
    statusMessage.style.display = 'block';
    resultsContainer.style.display = 'none';
};

const renderResults = (results) => {
    resultsContainer.innerHTML = '';
    if (results.length === 0) {
        showStatus('🎉 No images needing alt text were found on this page!', false);
        return;
    }
    statusMessage.style.display = 'none';
    resultsContainer.style.display = 'block';

    results.forEach(result => {
        const resultItem = document.importNode(resultTemplate.content, true);
        
        resultItem.querySelector('img').src = result.src;
        resultItem.querySelector('.suggestion-text').textContent = result.suggestion;

        const copyButton = resultItem.querySelector('.copy-button');
        copyButton.addEventListener('click', () => {
            navigator.clipboard.writeText(result.suggestion).then(() => {
                copyButton.textContent = 'Copied!';
                setTimeout(() => copyButton.textContent = 'Copy Alt Text', 2000);
            });
        });

        const whyButton = resultItem.querySelector('.why-button');
        const detailsSection = resultItem.querySelector('.details-section');

        if (result.context && result.context.summary) {
            detailsSection.querySelector('.summary-text').textContent = result.context.summary;
            detailsSection.querySelector('.source-link').href = result.context.url;
        } else {
            whyButton.style.display = 'none';
        }

        whyButton.addEventListener('click', () => {
            detailsSection.hidden = !detailsSection.hidden;
        });

        resultsContainer.appendChild(resultItem);
    });
};

scanButton.addEventListener('click', async () => {
    showStatus('Scanning page...', true);
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        chrome.tabs.sendMessage(tab.id, { type: 'SCAN_PAGE' }, (response) => {
            if (chrome.runtime.lastError) {
                 showStatus(`Error: Could not connect to the page. Please reload it.`, false);
            } else {
                 showStatus('Analyzing images with AI...', true);
            }
        });
    } catch (error) {
        showStatus('Error: Could not find an active tab to scan.', false);
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'ANALYSIS_COMPLETE') {
        renderResults(request.payload);
    } else if (request.type === 'NO_IMAGES_FOUND') {
        renderResults([]);
    }
    // Necessário para manter o canal de mensagem aberto para respostas assíncronas
    return true;
});